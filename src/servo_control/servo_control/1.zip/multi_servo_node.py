import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
import serial
import time

class MultiServoNode(Node):
    def __init__(self):
        super().__init__('multi_servo_node')

        # Arduino Mega port
        self.ser = serial.Serial('/dev/ttyUSB0', 57600, timeout=1)
        time.sleep(2)

        # Subscribers
        self.create_subscription(Int32, 'neck_cmd', self.cb_neck, 10)
        self.create_subscription(Int32, 'left_arm_cmd', self.cb_left, 10)
        self.create_subscription(Int32, 'right_arm_cmd', self.cb_right, 10)
        self.create_subscription(Int32, 'swing_cmd', self.cb_swing, 10)

        self.get_logger().info("Multi Servo Node READY")

    # -------------------------------------------------
    # Callbacks
    # -------------------------------------------------

    def cb_neck(self, msg):
        self.send(f"N {msg.data}")

    def cb_left(self, msg):
        self.send(f"L {msg.data}")

    def cb_right(self, msg):
        self.send(f"R {msg.data}")

    def cb_swing(self, msg):
        self.send(f"M {msg.data}")

    # -------------------------------------------------
    # Serial send function
    # -------------------------------------------------

    def send(self, text):
        cmd = text + "\r"     # IMPORTANT: Arduino expects CR=13
        self.ser.write(cmd.encode())
        self.get_logger().info(f"Sent: {text}")


def main(args=None):
    rclpy.init(args=args)
    node = MultiServoNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()